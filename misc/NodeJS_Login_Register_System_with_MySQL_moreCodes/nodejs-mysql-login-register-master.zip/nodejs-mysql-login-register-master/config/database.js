module.exports = {
 'connection':{
  'host':'localhost',
  'user':'root1',
  'password':''
 },
 'database':'nodejs_login',
 'user_table':'users'
}